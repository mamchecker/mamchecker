void command(int a);
