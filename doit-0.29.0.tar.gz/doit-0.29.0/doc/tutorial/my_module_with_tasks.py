
def task_sample():
    return {'actions': ['echo hello from module loader'],
            'verbosity': 2,}

