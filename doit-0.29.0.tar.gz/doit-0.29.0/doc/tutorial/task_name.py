def task_hello():
    return {
        'actions': ['echo hello']
        }

def task_xxx():
    return {
        'basename': 'hello2',
        'actions': ['echo hello2']
        }
